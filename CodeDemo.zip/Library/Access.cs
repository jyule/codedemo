﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeDemo.Library
	{
	#region Public Exceptions *******************************************
	public class JJYAccessException : ApplicationException
		{
		public JJYAccessException()
			{
			}
		public JJYAccessException(string message)
			: base(message)
			{
			}
		public JJYAccessException(string message, Exception inner)
			: base(message, inner)
			{
			}
		}
	#endregion Public Exceptions


	#region CLASS Access
	/// <summary>
	/// Summary description for Access.
	/// </summary>
	public class Access
		{

		private const string DEMO_SERVER = "10.0.0.114";
		private const string DEMO_DATABASE = "CodeDemo";
		private const string DEMO_USERNAME = "CodeDemoUser";
		private const string DEMO_PASSWORD = "CodeDemoUser";


		#region Constructors *********************************************************
		public Access()
			{
			}
		#endregion Constructors


		#region Properties ***********************************************************
		#endregion Properties

		#region Public Static Methods *******************************************************

		//======================================================================================
		// CodeDemo Connections
		//======================================================================================
		/// <summary>
		/// Creates an active SQL connection based ont he  login registry
		/// </summary>
		/// <returns></returns>
		static public System.Data.SqlClient.SqlConnection GetSqlConnection()
			{
			try
				{
				System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(MakeSqlConnectionString());
				conn.Open();
				return (conn);
				}
			catch (JJYAccessException e)
				{
				throw new JJYAccessException(e.Message);
				}
			catch (Exception e)
				{
				throw new JJYAccessException(e.Message);
				}
			}

		static public string MakeSqlConnectionString()
			{
			return (MakeSqlConnectionString(DEMO_SERVER, DEMO_DATABASE, DEMO_USERNAME, DEMO_PASSWORD, false));
			}

		static public string MakeSqlConnectionString(string server, string database, string userName, string password, bool useWindowsAuthentication)
			{
			string sConnect = "", sErrMsg = "";
			string sDecryptPassword = "";

			sConnect += string.Format("DATA SOURCE={0}; INITIAL CATALOG={1};", server, database);
			sConnect += useWindowsAuthentication ?
							"INTEGRATED SECURITY=sspi;TRUSTED_CONNECTION=yes;" :
							string.Format("USER ID={0}; PASSWORD={1};", userName, password);
			return (sConnect);
			}
		#endregion Public Static Methods *******************************************************
		}
	#endregion CLASS Access
	}