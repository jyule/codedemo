﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace CodeDemo.Library
	{
	//==========================================================================================================
	#region CLASS Catalog
	/// <summary>
	/// This would be the base class to encapsulate collections of media types, and a central place to perfrom basic catalog operations
	/// </summary>
	public class Catalog
		{
		#region Constructors/Destructor
		//-----------------------------------------------------------------------
		public Catalog()
			{
			Initialize();
			}
		#endregion Constructors/Destructor

		#region Public Methods
		//-----------------------------------------------------------------------
		public void Initialize()
			{
			}

		//-----------------------------------------------------------------------
		/// <summary>
		/// Queries the backend database by any combination of author, title and isbn.
		/// </summary>
		/// <param name="title"></param>
		/// <param name="author"></param>
		/// <param name="isbn"></param>
		/// <returns></returns>
		public List<CatalogItem> QueryCatalog(string title, string author, string isbn)
			{
			SqlConnection conn = null;
			SqlCommand cmd = null;
			JJYReader rdr = null;
			List<CatalogItem> items = new List<CatalogItem>();

			try
				{
				conn = Library.Access.GetSqlConnection();
				cmd = new SqlCommand("[dbo].[SP_QueryCatalog]", conn);
				cmd.CommandType = System.Data.CommandType.StoredProcedure;
				cmd.Parameters.AddWithValue("@Author", author);
				cmd.Parameters.AddWithValue("@Title", title);
				cmd.Parameters.AddWithValue("@ISBN", isbn);

				rdr = new JJYReader(cmd.ExecuteReader());

				while (rdr.Read())
					items.Add(new CatalogItem(rdr));

				return (items);
				}
			catch (Exception ex)
				{
				throw new Exception(string.Format("Query Catalog has encountered a fatal error: {0}", ex.Message));
				}
			finally
				{
				if (rdr != null)
					rdr.Close();
				if (conn != null)
					conn.Close();
				}
			}
		#endregion Public Methods
		}
	#endregion CLASS Catalog

	//==========================================================================================================
	/// <summary>
	/// This would be the base class to encapsulate collections of items associated with a Patron
	/// </summary>
	#region CLASS Patron
	public class Patron
		{
		#region Constructors/Destructor
		//-----------------------------------------------------------------------
		public Patron()
			{
			Initialize();
			}
		#endregion Constructors/Destructor

		#region Public Methods
		//-----------------------------------------------------------------------
		public void Initialize()
			{
			}

		//-----------------------------------------------------------------------
		/// <summary>
		/// Queries the backend database by any combination of author, title and isbn.
		/// </summary>
		/// <param name="title"></param>
		/// <param name="author"></param>
		/// <param name="isbn"></param>
		/// <returns></returns>
		public List<CatalogItem> GetPatronItems(int patronID)
			{
			SqlConnection conn = null;
			SqlCommand cmd = null;
			JJYReader rdr = null;
			List<CatalogItem> items = new List<CatalogItem>();
			CatalogItem item;
			try
				{
				conn = Library.Access.GetSqlConnection();
				cmd = new SqlCommand("[dbo].[SP_GetPatronItems]", conn);
				cmd.CommandType = System.Data.CommandType.StoredProcedure;
				cmd.Parameters.AddWithValue("@PatronID", patronID);

				rdr = new JJYReader(cmd.ExecuteReader());

				while (rdr.Read())
					{
					items.Add(new CatalogItem(rdr));
					}

				return (items);
				}
			catch (Exception ex)
				{
				throw new Exception(string.Format("Query Patron Items has encountered a fatal error: {0}", ex.Message));
				}
			finally
				{
				if (rdr != null)
					rdr.Close();
				if (conn != null)
					conn.Close();
				}
			}
		#endregion Public Methods
		}
	#endregion CLASS Patron


	//==========================================================================================================
	#region CLASS CatalogItem
	/// <summary>
	/// Base class for all catalog items regardless of media type (needs a lot more work)
	/// </summary>
	public class CatalogItem
		{
		public enum Dispositions
			{
			Available = 1,
			CheckedOut,
			OnHold
			}

		#region Properties
		//--------------------
		private int m_iBookID;
		public int CatalogID
			{
			get { return(m_iBookID); }
			set { m_iBookID = value; }
			}
		//--------------------
		private string m_sAuthor;
		public string Author
			{
			get { return (m_sAuthor); }
			set { m_sAuthor = value; }
			}
		//--------------------
		private string m_sTitle;
		public string Title
			{
			get { return (m_sTitle); }
			set { m_sTitle = value; }
			}
		//--------------------
		private string m_sSubject;
		public string Subject
			{
			get { return (m_sSubject); }
			set { m_sSubject = value; }
			}
		//--------------------
		private string m_sSynopsis;
		public string Synopsis
			{
			get { return (m_sSynopsis); }
			set { m_sSynopsis = value; }
			}
		//--------------------
		private string m_sISBN;
		public string ISBN
			{
			get { return (m_sISBN); }
			set { m_sISBN = value; }
			}
		//--------------------
		private DateTime m_dtePublishDate;
		public DateTime PublishDate
			{
			get { return (m_dtePublishDate); }
			set { m_dtePublishDate = value; }
			}
		//--------------------
		private int m_iPageCount;
		public int PageCount
			{
			get { return (m_iPageCount); }
			set { m_iPageCount = value; }
			}
		//--------------------
		private string m_sDisposition;
		public string Disposition
			{
			get { return (m_sDisposition); }
			set { m_sDisposition = value; }
			}
		//--------------------
		private int m_iPatronID;
		public int PatronID
			{
			get { return (m_iPatronID); }
			set { m_iPatronID = value; }
			}
		//--------------------
		private DateTime m_dteDueDate;
		public DateTime DueDate
			{
			get { return (m_dteDueDate); }
			set { m_dteDueDate = value; }
			}
		#endregion Properties

		#region Constructors/Destructor
		//-----------------------------------------------------------------------
		/// <summary>
		/// Instantiate a new CatalogItem with default values.
		/// </summary>
		public CatalogItem()
			{
			Initialize();
			}

		public CatalogItem(int catalogID)
			{
			Load(catalogID);
			}


		//-----------------------------------------------------------------------
		/// <summary>
		/// Instantiate a new CatalogItem instance and initialize froma  pre-initializedSql reader object.
		/// </summary>
		/// <param name="rdr"></param>
		public CatalogItem(int catalogID, string author, string title, string subject, string synopsis, string isbn, DateTime publishDate, int pageCount, string disposition, int patronID )
			{
			Initialize();
			Populate(catalogID, author, title, subject, synopsis, isbn, publishDate, pageCount, disposition, patronID);
			}

		//-----------------------------------------------------------------------
		/// <summary>
		/// Instantiate a new CatalogItem instance and initialize froma  pre-initializedSql reader object.
		/// </summary>
		/// <param name="rdr"></param>
		public CatalogItem(JJYReader rdr)
			{
			Initialize();
			Populate(rdr);
			}
		#endregion Constructors/Destructor

		#region Public Methods
		//-----------------------------------------------------------------------
		/// <summary>
		/// Initialize the CatalogItem to it's default values.
		/// </summary>
		public void Initialize()
			{
			CatalogID = 0;
			Author = "";
			Title = "";
			Subject = "";
			Synopsis = "";
			ISBN = "";
			PublishDate = DateTime.Parse("1/1/1901");
			PageCount = 0;
			Disposition = "";
			PatronID = 0;
			DueDate = DateTime.Parse("1/1/1901");
			}

		//-----------------------------------------------------------------------
		/// <summary>
		/// Populate the CatalogItem using passed paramaters.
		/// </summary>
		/// <param name="catalogID"></param>
		/// <param name="author"></param>
		/// <param name="title"></param>
		/// <param name="subject"></param>
		/// <param name="synopsis"></param>
		/// <param name="isbn"></param>
		/// <param name="publishDate"></param>
		/// <param name="pageCount"></param>
		public void Populate(int catalogID, string author, string title, string subject, string synopsis, string isbn, DateTime publishDate, int pageCount, string disposition, int patronID)
			{
			this.CatalogID = catalogID;
			this.Author = author;
			this.Title = title;
			this.Subject = subject;
			this.Synopsis = synopsis;
			this.ISBN = isbn;
			this.PublishDate = publishDate;
			this.PageCount = pageCount;
			this.Disposition = disposition;
			this.PatronID = patronID;
			}

		//-----------------------------------------------------------------------
		/// <summary>
		/// Populate the CatalogItem using a pre-initalized/read Sql Reader.
		/// </summary>
		/// <param name="rdr"></param>
		public void Populate(JJYReader rdr)
			{
			try
				{
				this.CatalogID = rdr.GetReaderSafeValueInt32("CatalogID", 0);
				this.Author = rdr.GetReaderSafeValueString("Author", "");
				this.Title = rdr.GetReaderSafeValueString("Title", "");
				this.Subject = rdr.GetReaderSafeValueString("Subject", "");
				this.Synopsis = rdr.GetReaderSafeValueString("Synopsis", "");
				this.ISBN = rdr.GetReaderSafeValueString("ISBN", "");
				this.PublishDate = rdr.GetReaderSafeValueDate("PublishDate", DateTime.Parse("1/1/1901"));
				this.PageCount = rdr.GetReaderSafeValueInt32("PageCount", 0);
				this.Disposition = rdr.GetReaderSafeValueString("Disposition", "");
				this.PatronID = rdr.GetReaderSafeValueInt32("PatronID", 0);
				this.DueDate = rdr.GetReaderSafeValueDate("DueDate", DateTime.Parse("1/1/1901"));
				}
			catch 
				{
				Initialize();
				}
			}



		//-----------------------------------------------------------------------
		public void Load(int catalogID)
			{
			SqlConnection conn = null;
			SqlCommand cmd = null;
			JJYReader rdr = null;

			try
				{
				conn = Library.Access.GetSqlConnection();
				cmd = new SqlCommand("[dbo].[SP_GetCatalogItem]", conn);
				cmd.CommandType = System.Data.CommandType.StoredProcedure;
				cmd.Parameters.AddWithValue("@CatalogID", catalogID);

				rdr = new JJYReader(cmd.ExecuteReader());
				rdr.Read();

				Populate(rdr);
				}
			catch (Exception ex)
				{
				throw new Exception(string.Format("Load Catalog Item has encountered a fatal error: {0}", ex.Message));
				}
			finally
				{
				if (rdr != null)
					rdr.Close();
				if (conn != null)
					conn.Close();
				}
			}
		//-----------------------------------------------------------------------
		public void Save()
			{
			}
		//-----------------------------------------------------------------------
		/// <summary>
		/// Checks-out the media to the associated Patron.
		/// </summary>
		/// <param name="patronID"></param>
		/// <returns></returns>
		public object CheckOut(int patronID)
			{
			bool bResult;
			SqlConnection conn = null;
			SqlCommand cmd = null;

			// if the sql operations were being done in code i would use sql transactions
			// but all work is being done in a stored procedure (which does use transactions)
			try
				{
				conn = Library.Access.GetSqlConnection();
				cmd = new SqlCommand("[dbo].[SP_CheckOutCatalogItem]", conn);
				cmd.CommandType = System.Data.CommandType.StoredProcedure;
				cmd.Parameters.AddWithValue("@CatalogID", this.CatalogID);
				cmd.Parameters.AddWithValue("@PatronID", patronID);

				return(cmd.ExecuteScalar());
				}
			catch (Exception ex)
				{
				throw new Exception(string.Format("CheckOut has encountered a fatal error: {0}", ex.Message));
				}
			finally
				{
				if (conn != null)
					conn.Close();
				}
			}
		//-----------------------------------------------------------------------
		/// <summary>
		/// Checks-in the media back to available status (or on-hold if a Patron reserved it).
		/// </summary>
		public bool CheckIn()
			{
			bool bResult;
			SqlConnection conn = null;
			SqlCommand cmd = null;

			// if the sql operations were being done in code i would use sql transactions
			// but all work is being done in a stored procedure (which does use transactions)
			try
				{
				conn = Library.Access.GetSqlConnection();
				cmd = new SqlCommand("[dbo].[SP_CheckInCatalogItem]", conn);
				cmd.CommandType = System.Data.CommandType.StoredProcedure;
				cmd.Parameters.AddWithValue("@CatalogID", this.CatalogID);
				cmd.Parameters.AddWithValue("@PatronID", 100);

				return ((bool)cmd.ExecuteScalar());
				}
			catch (Exception ex)
				{
				throw new Exception(string.Format("CheckIn has encountered a fatal error: {0}", ex.Message));
				}
			finally
				{
				if (conn != null)
					conn.Close();
				}
			}

		#endregion Public Methods

		}
	#endregion CLASS CatalogItem

	//==========================================================================================================
	#region CLASS BOOK
	/// <summary>
	/// A CatalogItem of type Book.  Not really hooked up to anything at this point, but you see where this leads...
	/// </summary>
	public class Book : CatalogItem
		{
		//-----------------------------------------------------------------------
		public Book()
			:base()
			{
			}

		public Book(int catalogID)
			:base(catalogID)
			{
			}

		//-----------------------------------------------------------------------
		public Book(int catalogID, string author, string title, string subject, string synopsis, string isbn, DateTime publishDate, int pageCount, string disposition, int patronID )
			:base(catalogID, author, title, subject, synopsis, isbn, publishDate, pageCount, disposition, patronID)
			{
			}

		//-----------------------------------------------------------------------
		public Book(JJYReader rdr)
			:base(rdr)
			{
			}
		}
	#endregion CLASS BOOK

	//==========================================================================================================
	#region CLASS Audio
	/// <summary>
	/// A CatalogItem of type Book.  Not really hooked up to anything at this point, but you see where this leads...
	/// </summary>
	public class Audio : CatalogItem
		{
		//-----------------------------------------------------------------------
		public Audio()
			: base()
			{
			}

		public Audio(int catalogID)
			: base(catalogID)
			{
			}

		//-----------------------------------------------------------------------
		public Audio(int catalogID, string author, string title, string subject, string synopsis, string isbn, DateTime publishDate, int pageCount, string disposition, int patronID)
			: base(catalogID, author, title, subject, synopsis, isbn, publishDate, pageCount, disposition, patronID)
			{
			}

		//-----------------------------------------------------------------------
		public Audio(JJYReader rdr)
			: base(rdr)
			{
			}
		}
	#endregion CLASS Audio

	//==========================================================================================================
	#region CLASS Audio
	/// <summary>
	/// A CatalogItem of type Video.  Not really hooked up to anything at this point, but you see where this leads...
	/// </summary>
	public class Video : CatalogItem
		{
		//-----------------------------------------------------------------------
		public Video()
			: base()
			{
			}

		public Video(int catalogID)
			: base(catalogID)
			{
			}

		//-----------------------------------------------------------------------
		public Video(int catalogID, string author, string title, string subject, string synopsis, string isbn, DateTime publishDate, int pageCount, string disposition, int patronID)
			: base(catalogID, author, title, subject, synopsis, isbn, publishDate, pageCount, disposition, patronID)
			{
			}

		//-----------------------------------------------------------------------
		public Video(JJYReader rdr)
			: base(rdr)
			{
			}
		}
	#endregion CLASS Video

	}
