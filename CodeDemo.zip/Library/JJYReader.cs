﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeDemo.Library
	{
	using System;
	using System.Data;
	//using System.Data.OleDb;
	using System.Data.SqlClient;

	#region Public Exceptions *******************************************
	public class JJYReaderException : ApplicationException
		{
		public JJYReaderException()
			{
			}
		public JJYReaderException(string message)
			: base(message)
			{
			}
		public JJYReaderException(string message, Exception inner)
			: base(message, inner)
			{
			}
		}
	#endregion Public Exceptions


	/// <summary>
	/// Summary description for JJYReader.
	/// </summary>
	public class JJYReader
		{
		public JJYReader()
			{
			m_rdr = null;
			}
		public JJYReader(System.Data.SqlClient.SqlDataReader rdr)
			{
			m_rdr = rdr;
			}

		//----------------------------------
		public bool Read()
			{
			try
				{
				return (m_rdr.Read());
				}
			catch (Exception e)
				{
				throw new JJYReaderException(e.Message);
				}
			}

		//----------------------------------
		public void Close()
			{
			try
				{
				m_rdr.Close();
				}
			catch (Exception e)
				{
				throw new JJYReaderException(e.Message);
				}
			}

		//----------------------------------
		private System.Data.SqlClient.SqlDataReader m_rdr;
		public System.Data.SqlClient.SqlDataReader Reader
			{
			get { return (m_rdr); }
			set { m_rdr = value; }
			}

		//----------------------------------
		public bool HasRows
			{
			get
				{
				try { return (m_rdr.HasRows); }
				catch { return (false); }
				}
			}

		//----------------------------------
		public bool IsClosed
			{
			get
				{
				try { return (m_rdr.IsClosed); }
				catch { return (false); }
				}
			}

		//----------------------------------
		public int GetOrdinal(string sName)
			{
			try
				{
				return (m_rdr.GetOrdinal(sName));
				}
			catch (Exception e)
				{
				return (-1);
				}
			}
		//----------------------------------
		public int FieldCount
			{
			get { return (m_rdr.FieldCount); }
			}

		//----------------------------------
		public string GetName(int index)
			{
			return (m_rdr.GetName(index));
			}

		//----------------------------------
		public string GetName(string column)
			{
			int x;
			return ((x = m_rdr.GetOrdinal(column)) >= 0 ? m_rdr.GetName(x) : "");
			}

		//----------------------------------
		public string GetDataTypeName(int idx)
			{
			return (m_rdr.GetDataTypeName(idx));
			}

		//----------------------------------
		public bool IsDBNull(int idx)
			{
			return (m_rdr.IsDBNull(idx));
			}
		//----------------------------------
		public int GetInt32(int idx)
			{
			return (m_rdr.GetInt32(idx));
			}
		//----------------------------------
		public short GetInt16(int idx)
			{
			return (m_rdr.GetInt16(idx));
			}
		//----------------------------------
		public byte GetByte(int idx)
			{
			return (m_rdr.GetByte(idx));
			}
		//----------------------------------
		public string GetString(int idx)
			{
			return (m_rdr.GetString(idx));
			}
		//----------------------------------
		public DataTable GetSchemaTable()
			{
			return (m_rdr.GetSchemaTable());
			}
		//----------------------------------
		public DateTime GetDateTime(int idx)
			{
			return (m_rdr.GetDateTime(idx));
			}

		//========================================
		/// <summary>
		/// Returns a 'safe' object for the associated column index.
		/// </summary>
		/// <param name="index"></param>
		/// <param name="defaultValue"></param>
		/// <returns></returns>
		public object GetReaderSafeValue(int index, object defaultValue)
			{
			try
				{
				return (m_rdr.IsDBNull(index) ? null : m_rdr.GetValue(index));
				}
			catch { return (defaultValue); }
			}
		/// <summary>
		/// Returns a 'safe' object for the associated column name.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="defaultValue"></param>
		/// <returns></returns>
		public object GetReaderSafeValue(string columnName, object defaultValue)
			{
			try
				{
				int index = m_rdr.GetOrdinal(columnName);
				return (m_rdr.GetValue(index));
				}
			catch { return (defaultValue); }
			}
		//========================================
		/// <summary>
		/// Returns a 'safe' string for the associated column index.
		/// </summary>
		/// <param name="index"></param>
		/// <param name="sDefaultValue"></param>
		/// <returns></returns>
		public string GetReaderSafeValueString(int index, string sDefaultValue)
			{
			try
				{
				if (m_rdr.IsDBNull(index))
					return (sDefaultValue);
				return (m_rdr.GetString(index));
				}
			catch { return (sDefaultValue); }
			}
		/// <summary>
		/// Returns a 'safe' string for the associated column name.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="sDefaultValue"></param>
		/// <returns></returns>
		public string GetReaderSafeValueString(string columnName, string sDefaultValue)
			{
			try
				{
				int index = m_rdr.GetOrdinal(columnName);
				if (m_rdr.IsDBNull(index))
					return (sDefaultValue);
				return (m_rdr.GetString(index));
				}
			catch { return (sDefaultValue); }
			}

		//========================================
		/// <summary>
		/// Returns a 'safe' int (from 8 bit byte) for the associated column index.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public int GetReaderSafeValueInt8(string columnName, int iDefaultValue)
			{
			try
				{
				int index = m_rdr.GetOrdinal(columnName);
				if (m_rdr.IsDBNull(index))
					return (iDefaultValue);
				return (m_rdr.GetByte(index));
				}
			catch { return (iDefaultValue); }
			}

		//========================================
		/// <summary>
		/// Returns a 'safe' int (from 8 bit byte) for the associated column index.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public int GetReaderSafeValueInt8(int index, int iDefaultValue)
			{
			try
				{
				if (m_rdr.IsDBNull(index))
					return (iDefaultValue);
				return ((int)m_rdr.GetByte(index));
				}
			catch { return (iDefaultValue); }
			}

		//========================================
		/// <summary>
		/// Returns a 'safe' int (from 16 bit word) for the associated column index.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public int GetReaderSafeValueInt16(int index, int iDefaultValue)
			{
			try
				{
				if (m_rdr.IsDBNull(index))
					return (iDefaultValue);
				return (m_rdr.GetInt16(index));
				}
			catch { return (iDefaultValue); }
			}

		/// <summary>
		/// Returns a 'safe' int (from 16 bit word) for the associated column index.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public int GetReaderSafeValueInt16(string columnName, int iDefaultValue)
			{
			try
				{
				int index = m_rdr.GetOrdinal(columnName);
				if (m_rdr.IsDBNull(index))
					return (iDefaultValue);
				return (m_rdr.GetInt16(index));
				}
			catch { return (iDefaultValue); }
			}

		//========================================
		/// <summary>
		/// Returns a 'safe' int for the associated column index.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public int GetReaderSafeValueInt32(int index, int iDefaultValue)
			{
			try
				{
				if (m_rdr.IsDBNull(index))
					return (iDefaultValue);
				return (m_rdr.GetInt32(index));
				}
			catch { return (iDefaultValue); }
			}

		// <summary>
		/// Returns a 'safe' int for the associated column name.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public int GetReaderSafeValueInt32(string columnName, int iDefaultValue)
			{
			int index = -1;
			try
				{
				index = m_rdr.GetOrdinal(columnName.ToString());
				if (m_rdr.IsDBNull(index))
					return (iDefaultValue);
				return (m_rdr.GetInt32(index));
				}
			catch { return (iDefaultValue); }
			}

		// <summary>
		/// Returns a 'safe' int for the associated column name, and cycles through int types from 32 to 8
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public int GetReaderSafeValueIntAny(string columnName, int iDefaultValue)
			{
			int index = -1;
			int result = 0;
			try
				{
				index = m_rdr.GetOrdinal(columnName.ToString());
				if (m_rdr.IsDBNull(index))
					return (iDefaultValue);

				try
					{
					result = m_rdr.GetInt32(index);
					}
				catch
					{
					try
						{
						result = m_rdr.GetInt16(index);
						}
					catch
						{
						result = m_rdr.GetByte(index);
						}
					}
				}
			catch
				{
				result = iDefaultValue;
				}
			return (result);
			}

		//========================================
		/// <summary>
		/// Returns a 'safe' float for the associated column index.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public float GetReaderSafeValueFloat(int index, float fDefaultValue)
			{
			try
				{
				if (m_rdr.IsDBNull(index))
					return (fDefaultValue);
				return (m_rdr.GetFloat(index));
				}
			catch { return (fDefaultValue); }
			}
		/// <summary>
		/// Returns a 'safe' float for the associated column name.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public float GetReaderSafeValueFloat(string columnName, float fDefaultValue)
			{
			int index = -1;
			try
				{
				index = m_rdr.GetOrdinal(columnName.ToString());
				if (m_rdr.IsDBNull(index))
					return (fDefaultValue);
				return (m_rdr.GetFloat(index));
				}
			catch { return (fDefaultValue); }
			}

		/// <summary>
		/// Returns a 'safe' double for the associated column name.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public double GetReaderSafeValueDouble(string columnName, double dDefaultValue)
			{
			int index = -1;
			try
				{
				index = m_rdr.GetOrdinal(columnName.ToString());
				if (m_rdr.IsDBNull(index))
					return (dDefaultValue);
				return (m_rdr.GetDouble(index));
				}
			catch { return (dDefaultValue); }
			}


		//========================================
		/// <summary>
		/// Returns a 'safe' Money for the associated column index.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public double GetReaderSafeValueMoney(int index, double fDefaultValue)
			{
			try
				{
				if (m_rdr.IsDBNull(index))
					return (fDefaultValue);
				return (System.Convert.ToDouble(m_rdr.GetSqlMoney(index)));
				}
			catch { return (fDefaultValue); }
			}
		/// <summary>
		/// Returns a 'safe' float for the associated column name.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="iDefaultValue"></param>
		/// <returns></returns>
		public double GetReaderSafeValueMoney(string columnName, double fDefaultValue)
			{
			int index = -1;
			try
				{
				index = m_rdr.GetOrdinal(columnName.ToString());
				if (m_rdr.IsDBNull(index))
					return (fDefaultValue);
				return (System.Convert.ToDouble(m_rdr.GetSqlMoney(index).ToString()));
				}
			catch { return (fDefaultValue); }
			}

		//========================================
		/// <summary>
		/// Returns a 'safe' bool for the associated column index.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="bDefaultValue"></param>
		/// <returns></returns>
		public bool GetReaderSafeValueBool(int index, bool bDefaultValue)
			{
			try
				{
				if (m_rdr.IsDBNull(index))
					return (bDefaultValue);
				return (m_rdr.GetBoolean(index));
				}
			catch { return (bDefaultValue); }
			}
		/// <summary>
		/// Returns a 'safe' bool for the associated column name.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="bDefaultValue"></param>
		/// <returns></returns>
		public bool GetReaderSafeValueBool(string columnName, bool bDefaultValue)
			{
			try
				{
				int index = m_rdr.GetOrdinal(columnName);
				if (m_rdr.IsDBNull(index))
					return (bDefaultValue);
				return (m_rdr.GetBoolean(index));
				}
			catch { return (bDefaultValue); }
			}


		//========================================
		/// <summary>
		/// Returns a 'safe' DateTime for the associated column index.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="dteDefaultValue"></param>
		/// <returns></returns>
		public DateTime GetReaderSafeValueDate(int index, DateTime dteDefaultValue)
			{
			try
				{
				if (m_rdr.IsDBNull(index))
					return (dteDefaultValue);
				return (m_rdr.GetDateTime(index));
				}
			catch { return (dteDefaultValue); }
			}
		/// <summary>
		/// Returns a 'safe' DateTime for the associated column name.
		/// </summary>
		/// <param name="sColumnName"></param>
		/// <param name="dteDefaultValue"></param>
		/// <returns></returns>
		public DateTime GetReaderSafeValueDate(string columnName, DateTime dteDefaultValue)
			{
			try
				{
				int index = m_rdr.GetOrdinal(columnName);
				if (m_rdr.IsDBNull(index))
					return (dteDefaultValue);
				return (m_rdr.GetDateTime(index));
				}
			catch { return (dteDefaultValue); }
			}

		}
	}
