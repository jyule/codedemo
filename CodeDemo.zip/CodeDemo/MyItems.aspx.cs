﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using CodeDemo.Library;


namespace CodeDemo
	{
	public partial class MyItems : System.Web.UI.Page
		{
		#region Events
		//---------------------------------------------------------------------
		protected void Page_Load(object sender, EventArgs e)
			{
			if (!IsPostBack)
				{
				QueryPatron();
				}
			}

		//---------------------------------------------------------------------
		/// <summary>
		/// Processes all checked catalog items for check-out
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnCheckIn_Click(object sender, EventArgs e)
			{
			CheckInSelectedItems();
			}


		#endregion Events


		#region Private Methods
		//---------------------------------------------------------------------
		/// <summary>
		/// Uses the library to perform the query based on entered criteria and binds the results to the listview
		/// </summary>
		private void QueryPatron()
			{
			ListView2.Items.Clear();

			try
				{
				// use library class to query the catalog database and populate the listview
				Library.Patron patron = new Library.Patron();
				List<Library.CatalogItem> items = patron.GetPatronItems(100);

				// no results no need to go further
				if (items.Count <= 0)
					{
					ListView2.Visible = false;
					lblStatus.Visible = false;
					lblNoItems.Visible = true;
					lblError.Visible = false;
					btnCheckIn.Visible = false;
					return;
					}

				// bind our catalog list to the listview
				ListView2.Visible = true;
				ListView2.DataSource = items;
				ListView2.DataBind();

				ListView2.Visible = true;
				lblStatus.Visible = true;
				lblStatus.Text = string.Format("You currently have {0} items checked-out.", items.Count);
				lblNoItems.Visible = false;
				lblError.Visible = false;
				btnCheckIn.Visible = true;
				}
			catch(Exception ex)
				{
				ListView2.Visible = false;
				lblStatus.Visible = false;
				lblNoItems.Visible = false;
				lblError.Visible = true;
				lblError.Text = string.Format("A fatal error occurred querying your items:\n{0}", ex.Message);
				btnCheckIn.Visible = false;
				}
			finally
				{
				}

			}

		private void CheckInSelectedItems()
			{
			CheckBox control;
			CatalogItem item = null;
			StringBuilder sbSuccess = new StringBuilder();
			StringBuilder sbError = new StringBuilder();

			foreach (ListViewItem lv in ListView2.Items)
				{
				control = (CheckBox)lv.FindControl("chkCheckOut");
				if (control.Checked)
					{
					try
						{
						item = new CatalogItem(Convert.ToInt32(((Label)lv.FindControl("lblCatalogID")).Text));
						item.PatronID = 100;
						if (item.CheckIn())
							sbSuccess.AppendFormat("Checked In: '{0}' '{1}'<br/>", item.Author, item.Title);
						else
							sbError.AppendFormat("Failed: {0}  {1}<br/>", item.Author, item.Title);

						}
					catch (Exception ex)
						{
						sbError.AppendFormat("Checked Out: {0}  {1}  {2}<br/>", item != null ? item.Author : "", item != null ? item.Title : "", ex.Message);
						}
					}

				}

			QueryPatron();
			lblStatus.Visible = sbSuccess.Length > 0;
			lblStatus.Text = sbSuccess.ToString() + "<br />";
			lblNoItems.Visible = (ListView2.Items.Count == 0);
			lblError.Visible = sbError.Length > 0;
			lblError.Text = sbError.ToString();
			}
		#endregion Private Methods

		}
	}