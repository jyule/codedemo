﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using CodeDemo.Library;


namespace CodeDemo
	{
	public partial class Catalog : System.Web.UI.Page
		{
		#region Events
		//---------------------------------------------------------------------
		protected void Page_Load(object sender, EventArgs e)
			{
			if (!IsPostBack)
				{
				ListView1.Visible = false;
				lblStatus.Visible = false;
				lblNoItems.Visible = false;
				lblError.Visible = false;
				btnCheckout.Visible = false;
				}
			}

		//---------------------------------------------------------------------
		protected void btnQuery_Click(object sender, EventArgs e)
			{
			QueryCatalog();
			}

		//---------------------------------------------------------------------
		/// <summary>
		/// Processes all checked catalog items for check-out
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnCheckout_Click(object sender, EventArgs e)
			{
			CheckOutSelectedItems();
			}

		//---------------------------------------------------------------------
		/// <summary>
		/// This event fires after the data is bound, and disables the check boxes for any records where the items are unavailable
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void ListView1_ItemDataBound(object sender, ListViewItemEventArgs e)
			{
			if (string.Compare(((Label)e.Item.FindControl("lblDisposition")).Text, "Available", true) != 0)
				((CheckBox)e.Item.FindControl("chkCheckOut")).Enabled = false;
			}

		#endregion Events


		#region Private Methods
		//---------------------------------------------------------------------
		/// <summary>
		/// Uses the library to perform the query based on entered criteria and binds the results to the listview
		/// </summary>
		private void QueryCatalog()
			{
			ListView1.Items.Clear();

			try
				{
				// use library class to query the catalog database and populate the listview
				Library.Catalog catalog = new Library.Catalog();
				List<Library.CatalogItem> items = catalog.QueryCatalog(txtTitle.Text, txtAuthor.Text, txtISBN.Text);

				// no results no need to go further
				if (items.Count <= 0)
					{
					ListView1.Visible = false;
					lblStatus.Visible = false;
					lblNoItems.Visible = true;
					lblError.Visible = false;
					btnCheckout.Visible = false;
					return;
					}

				// bind our catalog list to the listview
				ListView1.Visible = true;
				ListView1.DataSource = items;
				ListView1.DataBind();

				ListView1.Visible = true;
				lblStatus.Visible = true;
				lblStatus.Text = string.Format("Your query generated {0} results.", items.Count);
				lblNoItems.Visible = false;
				lblError.Visible = false;
				btnCheckout.Visible = true;
				}
			catch(Exception ex)
				{
				ListView1.Visible = false;
				lblStatus.Visible = false;
				lblNoItems.Visible = false;
				lblError.Visible = true;
				lblError.Text = string.Format("A fatal error occurred querying the Catalog:\n{0}", ex.Message);
				btnCheckout.Visible = false;
				}
			finally
				{
				}

			}

		private void CheckOutSelectedItems()
			{
			object oDueDate;
			CheckBox control;
			CatalogItem item = null;
			StringBuilder sbSuccess = new StringBuilder();
			StringBuilder sbError = new StringBuilder();

			foreach (ListViewItem lv in ListView1.Items)
				{
				control = (CheckBox)lv.FindControl("chkCheckOut");
				if (control.Checked)
					{
					try
						{
						item = new CatalogItem(Convert.ToInt32(((Label)lv.FindControl("lblCatalogID")).Text));
						if ((oDueDate = item.CheckOut(100)) != null)
							sbSuccess.AppendFormat("Checked Out: Due Date: {2} '{0}' '{1}'<br/>", item.Author, item.Title, ((DateTime)oDueDate).ToString("yyyy-MM-dd"));
						else
							sbError.AppendFormat("Failed: {0}  {1}<br/>", item.Author, item.Title);

						}
					catch (Exception ex)
						{
						sbError.AppendFormat("Checked Out: {0}  {1}  {2}<br/>", item != null ? item.Author : "", item != null ? item.Title : "", ex.Message);
						}
					}

				}
			ListView1.Visible = false;
			lblStatus.Visible = sbSuccess.Length > 0;
			lblStatus.Text = sbSuccess.ToString();
			lblNoItems.Visible = false;
			lblError.Visible = sbError.Length > 0;
			lblError.Text = sbError.ToString();
			btnCheckout.Visible = false;
			}
		#endregion Private Methods
		
		}
	}